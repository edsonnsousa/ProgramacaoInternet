from django.apps import AppConfig


class PoolsConfig(AppConfig):
    name = 'pools'
